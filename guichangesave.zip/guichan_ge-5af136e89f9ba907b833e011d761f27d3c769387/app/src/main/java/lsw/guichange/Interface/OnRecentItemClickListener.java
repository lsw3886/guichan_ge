package lsw.guichange.Interface;

/**
 * Created by lsw38 on 2017-08-11.
 */

public interface OnRecentItemClickListener {
    public void onRecentItemClick(int position);
}
