package lsw.guichange.Interface;

/**
 * Created by lsw38 on 2017-08-14.
 */

public interface FragmentDataChangeListener {
    public void Datachange();
}
