package lsw.guichange.Interface;

/**
 * Created by lsw38 on 2017-08-13.
 */

public interface OnPostItemClickListener {
    public void onPostItemClick(int position);

}
