package lsw.guichange.Interface;

public interface OnListItemClickListener{
            public void onListItemClick(int position);

        }